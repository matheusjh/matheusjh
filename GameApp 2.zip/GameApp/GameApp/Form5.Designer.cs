﻿namespace GameApp
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.txtAnswer = new System.Windows.Forms.TextBox();
            this.lblMathsSign = new System.Windows.Forms.Label();
            this.lblSecNumb = new System.Windows.Forms.Label();
            this.lblFstNumb = new System.Windows.Forms.Label();
            this.btnLeave = new System.Windows.Forms.Button();
            this.btnCheck = new System.Windows.Forms.Button();
            this.lblScoreNumber = new System.Windows.Forms.Label();
            this.lblTimer = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnStart = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Rosewood Std Regular", 41.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblTitle.Location = new System.Drawing.Point(4, 4);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(427, 160);
            this.lblTitle.TabIndex = 3;
            this.lblTitle.Text = "LEVEL 3 Multiplication";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAnswer
            // 
            this.lblAnswer.BackColor = System.Drawing.Color.Transparent;
            this.lblAnswer.Font = new System.Drawing.Font("Rosewood Std Regular", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnswer.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblAnswer.Location = new System.Drawing.Point(12, 312);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(220, 62);
            this.lblAnswer.TabIndex = 26;
            this.lblAnswer.Text = "Answer: ";
            // 
            // lblScore
            // 
            this.lblScore.BackColor = System.Drawing.Color.Transparent;
            this.lblScore.Font = new System.Drawing.Font("Rosewood Std Regular", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblScore.Location = new System.Drawing.Point(11, 383);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(174, 62);
            this.lblScore.TabIndex = 25;
            this.lblScore.Text = "Score: ";
            // 
            // txtAnswer
            // 
            this.txtAnswer.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.txtAnswer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAnswer.Font = new System.Drawing.Font("Rosewood Std Regular", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAnswer.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtAnswer.Location = new System.Drawing.Point(235, 312);
            this.txtAnswer.Multiline = true;
            this.txtAnswer.Name = "txtAnswer";
            this.txtAnswer.Size = new System.Drawing.Size(184, 68);
            this.txtAnswer.TabIndex = 24;
            this.txtAnswer.Text = "0";
            this.txtAnswer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblMathsSign
            // 
            this.lblMathsSign.BackColor = System.Drawing.Color.Transparent;
            this.lblMathsSign.Font = new System.Drawing.Font("Rosewood Std Regular", 60F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMathsSign.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblMathsSign.Location = new System.Drawing.Point(173, 218);
            this.lblMathsSign.Name = "lblMathsSign";
            this.lblMathsSign.Size = new System.Drawing.Size(68, 94);
            this.lblMathsSign.TabIndex = 23;
            this.lblMathsSign.Text = "*";
            // 
            // lblSecNumb
            // 
            this.lblSecNumb.BackColor = System.Drawing.Color.Transparent;
            this.lblSecNumb.Font = new System.Drawing.Font("Rosewood Std Regular", 60F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecNumb.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblSecNumb.Location = new System.Drawing.Point(265, 218);
            this.lblSecNumb.Name = "lblSecNumb";
            this.lblSecNumb.Size = new System.Drawing.Size(122, 94);
            this.lblSecNumb.TabIndex = 22;
            this.lblSecNumb.Text = "0";
            // 
            // lblFstNumb
            // 
            this.lblFstNumb.BackColor = System.Drawing.Color.Transparent;
            this.lblFstNumb.Font = new System.Drawing.Font("Rosewood Std Regular", 60F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFstNumb.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblFstNumb.Location = new System.Drawing.Point(47, 218);
            this.lblFstNumb.Name = "lblFstNumb";
            this.lblFstNumb.Size = new System.Drawing.Size(129, 94);
            this.lblFstNumb.TabIndex = 21;
            this.lblFstNumb.Text = "0";
            // 
            // btnLeave
            // 
            this.btnLeave.BackColor = System.Drawing.Color.Transparent;
            this.btnLeave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLeave.Font = new System.Drawing.Font("Rosewood Std Regular", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeave.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnLeave.Location = new System.Drawing.Point(15, 569);
            this.btnLeave.Name = "btnLeave";
            this.btnLeave.Size = new System.Drawing.Size(120, 80);
            this.btnLeave.TabIndex = 20;
            this.btnLeave.Text = "Leave";
            this.btnLeave.UseVisualStyleBackColor = false;
            // 
            // btnCheck
            // 
            this.btnCheck.BackColor = System.Drawing.Color.Transparent;
            this.btnCheck.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCheck.Font = new System.Drawing.Font("Rosewood Std Regular", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheck.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnCheck.Location = new System.Drawing.Point(141, 569);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(272, 80);
            this.btnCheck.TabIndex = 19;
            this.btnCheck.Text = " Check Answer";
            this.btnCheck.UseVisualStyleBackColor = false;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // lblScoreNumber
            // 
            this.lblScoreNumber.BackColor = System.Drawing.Color.Transparent;
            this.lblScoreNumber.Font = new System.Drawing.Font("Rosewood Std Regular", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScoreNumber.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblScoreNumber.Location = new System.Drawing.Point(191, 383);
            this.lblScoreNumber.Name = "lblScoreNumber";
            this.lblScoreNumber.Size = new System.Drawing.Size(101, 62);
            this.lblScoreNumber.TabIndex = 27;
            // 
            // lblTimer
            // 
            this.lblTimer.BackColor = System.Drawing.Color.Transparent;
            this.lblTimer.Font = new System.Drawing.Font("Rosewood Std Regular", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimer.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblTimer.Location = new System.Drawing.Point(328, 9);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(103, 70);
            this.lblTimer.TabIndex = 28;
            this.lblTimer.Text = "0";
            this.lblTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.Transparent;
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnStart.Font = new System.Drawing.Font("Rosewood Std Regular", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnStart.Location = new System.Drawing.Point(115, 469);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(150, 80);
            this.btnStart.TabIndex = 29;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(434, 661);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.lblTimer);
            this.Controls.Add(this.lblScoreNumber);
            this.Controls.Add(this.lblAnswer);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.txtAnswer);
            this.Controls.Add(this.lblMathsSign);
            this.Controls.Add(this.lblSecNumb);
            this.Controls.Add(this.lblFstNumb);
            this.Controls.Add(this.btnLeave);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.lblTitle);
            this.Name = "Form5";
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Form5_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblAnswer;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.TextBox txtAnswer;
        private System.Windows.Forms.Label lblMathsSign;
        private System.Windows.Forms.Label lblSecNumb;
        private System.Windows.Forms.Label lblFstNumb;
        private System.Windows.Forms.Button btnLeave;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.Label lblScoreNumber;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnStart;
    }
}