﻿namespace GameApp
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.txtAnswer = new System.Windows.Forms.TextBox();
            this.lblMathsSign = new System.Windows.Forms.Label();
            this.lblSecNumb = new System.Windows.Forms.Label();
            this.lblFstNumb = new System.Windows.Forms.Label();
            this.btnLeave = new System.Windows.Forms.Button();
            this.btnCheck = new System.Windows.Forms.Button();
            this.lblScoreNumber = new System.Windows.Forms.Label();
            this.lblTimer = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnStart = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Rosewood Std Regular", 41.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblTitle.Location = new System.Drawing.Point(12, 24);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(410, 156);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "LEVEL 2 Subtraction ";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTitle.Click += new System.EventHandler(this.lblTitle_Click);
            // 
            // lblAnswer
            // 
            this.lblAnswer.BackColor = System.Drawing.Color.Transparent;
            this.lblAnswer.Font = new System.Drawing.Font("Rosewood Std Regular", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnswer.ForeColor = System.Drawing.Color.White;
            this.lblAnswer.Location = new System.Drawing.Point(17, 319);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(220, 62);
            this.lblAnswer.TabIndex = 18;
            this.lblAnswer.Text = "Answer: ";
            this.lblAnswer.Click += new System.EventHandler(this.lblAnswer_Click);
            // 
            // lblScore
            // 
            this.lblScore.BackColor = System.Drawing.Color.Transparent;
            this.lblScore.Font = new System.Drawing.Font("Rosewood Std Regular", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.ForeColor = System.Drawing.Color.White;
            this.lblScore.Location = new System.Drawing.Point(16, 390);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(174, 62);
            this.lblScore.TabIndex = 17;
            this.lblScore.Text = "Score: ";
            this.lblScore.Click += new System.EventHandler(this.lblScore_Click);
            // 
            // txtAnswer
            // 
            this.txtAnswer.BackColor = System.Drawing.Color.White;
            this.txtAnswer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAnswer.Font = new System.Drawing.Font("Rosewood Std Regular", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAnswer.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtAnswer.Location = new System.Drawing.Point(238, 315);
            this.txtAnswer.Multiline = true;
            this.txtAnswer.Name = "txtAnswer";
            this.txtAnswer.Size = new System.Drawing.Size(184, 68);
            this.txtAnswer.TabIndex = 16;
            this.txtAnswer.Text = "0";
            this.txtAnswer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtAnswer.TextChanged += new System.EventHandler(this.txtAnswer_TextChanged);
            // 
            // lblMathsSign
            // 
            this.lblMathsSign.BackColor = System.Drawing.Color.Transparent;
            this.lblMathsSign.Font = new System.Drawing.Font("Rosewood Std Regular", 60F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMathsSign.ForeColor = System.Drawing.Color.White;
            this.lblMathsSign.Location = new System.Drawing.Point(173, 218);
            this.lblMathsSign.Name = "lblMathsSign";
            this.lblMathsSign.Size = new System.Drawing.Size(68, 94);
            this.lblMathsSign.TabIndex = 15;
            this.lblMathsSign.Text = "-";
            // 
            // lblSecNumb
            // 
            this.lblSecNumb.BackColor = System.Drawing.Color.Transparent;
            this.lblSecNumb.Font = new System.Drawing.Font("Rosewood Std Regular", 60F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecNumb.ForeColor = System.Drawing.Color.White;
            this.lblSecNumb.Location = new System.Drawing.Point(274, 218);
            this.lblSecNumb.Name = "lblSecNumb";
            this.lblSecNumb.Size = new System.Drawing.Size(118, 94);
            this.lblSecNumb.TabIndex = 14;
            this.lblSecNumb.Text = "0";
            // 
            // lblFstNumb
            // 
            this.lblFstNumb.BackColor = System.Drawing.Color.Transparent;
            this.lblFstNumb.Font = new System.Drawing.Font("Rosewood Std Regular", 60F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFstNumb.ForeColor = System.Drawing.Color.White;
            this.lblFstNumb.Location = new System.Drawing.Point(52, 218);
            this.lblFstNumb.Name = "lblFstNumb";
            this.lblFstNumb.Size = new System.Drawing.Size(121, 94);
            this.lblFstNumb.TabIndex = 13;
            this.lblFstNumb.Text = "0";
            this.lblFstNumb.Click += new System.EventHandler(this.lblFstNumb_Click);
            // 
            // btnLeave
            // 
            this.btnLeave.BackColor = System.Drawing.Color.Transparent;
            this.btnLeave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLeave.Font = new System.Drawing.Font("Rosewood Std Regular", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeave.ForeColor = System.Drawing.Color.White;
            this.btnLeave.Location = new System.Drawing.Point(24, 569);
            this.btnLeave.Name = "btnLeave";
            this.btnLeave.Size = new System.Drawing.Size(120, 80);
            this.btnLeave.TabIndex = 12;
            this.btnLeave.Text = "Leave";
            this.btnLeave.UseVisualStyleBackColor = false;
            this.btnLeave.Click += new System.EventHandler(this.btnLeave_Click);
            // 
            // btnCheck
            // 
            this.btnCheck.BackColor = System.Drawing.Color.Transparent;
            this.btnCheck.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCheck.Font = new System.Drawing.Font("Rosewood Std Regular", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheck.ForeColor = System.Drawing.Color.White;
            this.btnCheck.Location = new System.Drawing.Point(159, 569);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(263, 80);
            this.btnCheck.TabIndex = 11;
            this.btnCheck.Text = "Check Answer";
            this.btnCheck.UseVisualStyleBackColor = false;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // lblScoreNumber
            // 
            this.lblScoreNumber.BackColor = System.Drawing.Color.Transparent;
            this.lblScoreNumber.Font = new System.Drawing.Font("Rosewood Std Regular", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScoreNumber.Location = new System.Drawing.Point(196, 390);
            this.lblScoreNumber.Name = "lblScoreNumber";
            this.lblScoreNumber.Size = new System.Drawing.Size(101, 62);
            this.lblScoreNumber.TabIndex = 19;
            // 
            // lblTimer
            // 
            this.lblTimer.BackColor = System.Drawing.Color.Transparent;
            this.lblTimer.Font = new System.Drawing.Font("Rosewood Std Regular", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimer.ForeColor = System.Drawing.Color.White;
            this.lblTimer.Location = new System.Drawing.Point(319, 9);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(103, 70);
            this.lblTimer.TabIndex = 20;
            this.lblTimer.Text = "0";
            this.lblTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTimer.Click += new System.EventHandler(this.lblTimer_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.Transparent;
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnStart.Font = new System.Drawing.Font("Rosewood Std Regular", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.ForeColor = System.Drawing.Color.White;
            this.btnStart.Location = new System.Drawing.Point(132, 473);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(150, 80);
            this.btnStart.TabIndex = 21;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(434, 661);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.lblTimer);
            this.Controls.Add(this.lblScoreNumber);
            this.Controls.Add(this.lblAnswer);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.txtAnswer);
            this.Controls.Add(this.lblMathsSign);
            this.Controls.Add(this.lblSecNumb);
            this.Controls.Add(this.lblFstNumb);
            this.Controls.Add(this.btnLeave);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.lblTitle);
            this.Name = "Form4";
            this.Text = "Level 2 (Subtraction)";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblAnswer;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.TextBox txtAnswer;
        private System.Windows.Forms.Label lblMathsSign;
        private System.Windows.Forms.Label lblSecNumb;
        private System.Windows.Forms.Label lblFstNumb;
        private System.Windows.Forms.Button btnLeave;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.Label lblScoreNumber;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnStart;
    }
}