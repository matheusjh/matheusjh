﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace GameApp
{
    public partial class Form5 : Form
    {
    	SoundPlayer sound_effect = new SoundPlayer("E:/Unit 7 - SECOND ASSIGNMENT/GameApp/GameApp/Resources/Congratulations.wav");
        public int a;
        public int b;
        public int timeLeft;
        int score = 0;
        public Form5()
        {
            InitializeComponent();
            btnCheck.Enabled = false;
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            btnCheck.Enabled = false;
            btnStart.Enabled = true;
            int c = a * b;
            if (txtAnswer.Text == c.ToString())
            {
            	sound_effect.Play();
                timeLeft = 11;
                score++;
                lblScoreNumber.Text = Convert.ToString(score);
                if (lblScoreNumber.Text == "10")
                {
                    MessageBox.Show("Well done you have finished all the levels, you are very BRAVE!");
                    DialogResult dialogResult = MessageBox.Show("You have unlocked the bonus level, would you like to access the bonus Level", "Warning!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
                    if (dialogResult == DialogResult.Yes)
                    {
                        this.Hide();
                        timer1.Stop();
                        timeLeft = -1;
                        Form3 f3 = new Form3();
                        f3.ShowDialog();
                    }
                    else if (dialogResult == DialogResult.No)
                    {
                        MessageBox.Show("The application will return to the Menu!");
                        this.Hide();
                        timer1.Stop();
                        timeLeft = -1;
                        Form1 f1 = new Form1();
                        f1.ShowDialog();
                    }
                   
                }
            }
            if (txtAnswer.Text != c.ToString())
            {
                score--;
                lblScoreNumber.Text = Convert.ToString(score);
                MessageBox.Show("You Lose");
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timeLeft--;
            lblTimer.Text = timeLeft.ToString();
            if (timeLeft == 0)
            {
                this.Hide();
                Form1 f1 = new Form1();
                f1.ShowDialog();

            }
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Stop();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            sound_effect.Stop();
            timeLeft = 11;
            timer1.Start();
            Random r = new Random();
            a = r.Next(10) + 1;
            b = r.Next(10) + 1;
            lblFstNumb.Text = a.ToString();
            lblSecNumb.Text = b.ToString();

            btnStart.Enabled = false;
            btnCheck.Enabled = true;
        }
    }
}
