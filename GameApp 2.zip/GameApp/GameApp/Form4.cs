﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace GameApp
{

    public partial class Form4 : Form
    {
    	SoundPlayer sound_effect = new SoundPlayer("E:/Unit 7 - SECOND ASSIGNMENT/GameApp/GameApp/Resources/Congratulations.wav");
        int score = 0;
        public int a;
        public int b;
        public int timeLeft;

        public Form4()
        {
            InitializeComponent();
            btnCheck.Enabled = false;
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            btnCheck.Enabled = false;
            btnStart.Enabled = true;
            int c = a - b;
            if (txtAnswer.Text == c.ToString())
            {
            	sound_effect.Play();
                timeLeft = 21;
                score++;
                lblScoreNumber.Text = Convert.ToString(score);
                if (lblScoreNumber.Text == "10")
                {
                    this.Hide();
                    timer1.Stop();
                    timeLeft = -1;
                    Form5 f5 = new Form5();
                    f5.ShowDialog();
                }
            }
            if (txtAnswer.Text != c.ToString())
            {
                score--;
                lblScoreNumber.Text = Convert.ToString(score);
                MessageBox.Show("You Lose");
            }
        }

        private void lblFstNumb_Click(object sender, EventArgs e)
        {

        }

        private void btnLeave_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult4 = MessageBox.Show("Are you sure that you want to Leave? Your Score Will be Lost", "Warning!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dialogResult4 == DialogResult.Yes)
            {
                this.Hide();
                Form1 f1 = new Form1();
                f1.ShowDialog();
            }
            else if (dialogResult4 == DialogResult.No)
            {
                MessageBox.Show("The application won't be going back!");
            }

        }

        private void lblAnswer_Click(object sender, EventArgs e)
        {

        }

        private void txtAnswer_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblScore_Click(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void lblTimer_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            timeLeft--;
            lblTimer.Text = timeLeft.ToString();
            if (timeLeft == 0)
            {
                this.Hide();
                Form1 f1 = new Form1();
                f1.ShowDialog();

            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            sound_effect.Stop();
            timeLeft = 21;
            timer1.Start();
            Random r = new Random();
            a = r.Next(7, 12);
            b = r.Next(1, 6);
            lblFstNumb.Text = a.ToString();
            lblSecNumb.Text = b.ToString();

            btnStart.Enabled = false;
            btnCheck.Enabled = true;
        }
    }    
}
