﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace GameApp
{
    public partial class Form3 : Form
    {
    	SoundPlayer sound_effect = new SoundPlayer("E:/Unit 7 - SECOND ASSIGNMENT/GameApp/GameApp/Resources/Congratulations.wav");
        int score = 0;
        public int a;
        public int b;
        public int timeLeft;

        public Form3()
        {
            InitializeComponent();
            btnCheck.Enabled = false;
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            btnCheck.Enabled = false;
            btnStart.Enabled = true;
            int c = a * b;
            if (txtAnswer.Text == c.ToString())
            {
            	sound_effect.Play();
                timeLeft = 11;
                score++;
                lblScoreNumber.Text = Convert.ToString(score);
                if (lblScoreNumber.Text == "10")
                {
                    MessageBox.Show("Well Done You have complete the bonus level, showing once again your bravery");
                    this.Hide();
                    Form1 f1 = new Form1();
                    f1.ShowDialog();
                }
            }
            if (txtAnswer.Text != c.ToString())
            {
                score--;
                lblScoreNumber.Text = Convert.ToString(score);
                MessageBox.Show("You Lose");
            }
        }

        private void btnLeave_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult4 = MessageBox.Show("Are you sure that you want to Leave? Your Score Will be Lost", "Warning!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dialogResult4 == DialogResult.Yes)
            {
                this.Hide();
                Form1 f1 = new Form1();
                f1.ShowDialog();
            }
            else if (dialogResult4 == DialogResult.No)
            {
                MessageBox.Show("The application won't be going back!");
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            sound_effect.Stop();
            timeLeft = 11;
            timer1.Start();
            Random r = new Random();
            a = r.Next(12);
            b = r.Next(12);
            lblFstNumb.Text = a.ToString();
            lblSecNumb.Text = b.ToString();

            btnStart.Enabled = false;
            btnCheck.Enabled = true;
        }

        private void lblTimer_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timeLeft--;
            lblTimer.Text = timeLeft.ToString();
            if (timeLeft == 0)
            {
                this.Hide();
                Form1 f1 = new Form1();
                f1.ShowDialog();

            }
        }
    }
}
